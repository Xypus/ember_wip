Ninja.CompaniesController = Ember.ArrayController.extend({
  sortProperties: ['name']
})