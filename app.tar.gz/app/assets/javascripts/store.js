DS.RESTAdapter.reopen({
  namespace: 'api'
})

Ninja.ApplicationStore = DS.Store.extend({

});

Ninja.ApplicationAdapter = DS.ActiveModelAdapter.extend({

});


