Ninja.CompaniesNewRoute = Ember.Route.extend({
  
})