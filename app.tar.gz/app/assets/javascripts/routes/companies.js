Ninja.CompaniesRoute = Ember.Route.extend({
  model: function() { return this.store.find('company') }
})