class CompanySerializer < ActiveModel::Serializer
  attributes :id, :name, :description
end